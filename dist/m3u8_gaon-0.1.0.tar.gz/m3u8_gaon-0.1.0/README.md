# m3u8_downloader

A simple Python package to download and combine m3u8 video segments into a single video file.

## Installation

```bash
pip install m3u8_downloader
